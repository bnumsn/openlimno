Flow Title=steadySIM20200825
Program Version=5.07
Number of Profiles= 1 
Profile Names=20200825
River Rch & RM=Clinch River,Upper Reach     ,4893.771
  20.56
River Rch & RM=Clinch River,Main Stem       ,4648.18 
  15.42
River Rch & RM=Clinch River,Middle Reach    ,4279.376
  20.56
River Rch & RM=Clinch River,Lower Reach     ,3803.314
  21.76
River Rch & RM=North Fork,Tributary       ,98.29333
    1.2
River Rch & RM=Side Channel,Side Reach      ,406.5545
   5.14
Boundary for River Rch & Prof#=Clinch River,Upper Reach     , 1 
Up Type= 1 
Up Known WS=348.913
Dn Type= 0 
Boundary for River Rch & Prof#=Clinch River,Main Stem       , 1 
Up Type= 0 
Dn Type= 0 
Boundary for River Rch & Prof#=Clinch River,Middle Reach    , 1 
Up Type= 0 
Dn Type= 0 
Boundary for River Rch & Prof#=Clinch River,Lower Reach     , 1 
Up Type= 0 
Dn Type= 3 
Dn Slope=0.0002
Boundary for River Rch & Prof#=North Fork,Tributary       , 1 
Up Type= 1 
Up Known WS=347.219
Dn Type= 0 
Boundary for River Rch & Prof#=Side Channel,Side Reach      , 1 
Up Type= 0 
Dn Type= 0 
DSS Import StartDate=
DSS Import StartTime=
DSS Import EndDate=
DSS Import EndTime=
DSS Import GetInterval= 0 
DSS Import Interval=
DSS Import GetPeak= 0 
DSS Import FillOption= 0 
